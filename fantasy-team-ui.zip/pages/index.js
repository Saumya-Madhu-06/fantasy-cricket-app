
import Head from 'next/head';
import FantasyTeamForm from '../components/FantasyTeamForm';

export default function Home() {
  return (
    <>
      <Head>
        <title>Fantasy Team Generator</title>
      </Head>
      <main className="min-h-screen bg-gray-100 p-4">
        <FantasyTeamForm />
      </main>
    </>
  );
}
